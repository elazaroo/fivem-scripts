

INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('escudo', 'Escudo policial', 1)
;
