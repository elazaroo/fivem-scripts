# keko-escudo

Preview:
https://www.youtube.com/watch?v=M7DcJJcTWwo

Dependency <a href="https://github.com/overextended/ox_inventory">ox_inventory<a>
